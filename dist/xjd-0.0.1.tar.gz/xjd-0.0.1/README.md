# xjd

[![PyPI - Version](https://img.shields.io/pypi/v/xjd.svg)](https://pypi.org/project/xjd)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/xjd.svg)](https://pypi.org/project/xjd)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install xjd
```

## License

`xjd` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
